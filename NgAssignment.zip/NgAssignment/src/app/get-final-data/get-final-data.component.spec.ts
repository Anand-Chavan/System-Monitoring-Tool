import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetFinalDataComponent } from './get-final-data.component';

describe('GetFinalDataComponent', () => {
  let component: GetFinalDataComponent;
  let fixture: ComponentFixture<GetFinalDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetFinalDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetFinalDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
