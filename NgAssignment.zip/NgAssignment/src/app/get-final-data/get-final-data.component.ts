import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-final-data',
  templateUrl: './get-final-data.component.html',
  styleUrls: ['./get-final-data.component.css']
})
export class GetFinalDataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
