import { Component, OnInit } from '@angular/core';
import {MatStepperModule} from '@angular/material/stepper';
import {MatTableModule} from '@angular/material/table';
import {MatButtonModule} from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import {MatInputModule} from '@angular/material/input';

@Component({
  selector: 'app-start',
  templateUrl: './start.component.html',
  styleUrls: ['./start.component.css'],
})
export class StartComponent implements OnInit {

  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  myControl = new FormControl();
  practiceName :string=""
  practice :string=""
  address:any;
  city:any;
  state:any;
  zipcode:any;
  fullName:any;
  cell:Number;
  options: string[] = ['One', 'Two', 'Three'];
  submitted:boolean=false;
  data:any;
  filteredOptions: Observable<string[]>;
  email: any;
  dataSource:any;
  // dataSource: { FullName: any; Email: any; Cell: Number; Speciality: string; PracticeName: string; Adddress: any; city: any; State: any; ZipCode: any; };

  constructor(private _formBuilder: FormBuilder) { }

  ngOnInit(): void {

    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });

    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );


  }

  
  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().indexOf(filterValue) === 0);
  }

  submit()
  {
    this.dataSource =[{
      FullName:this.fullName,
      Email:this.email, 
      Cell:this.cell,
      Speciality:this.practiceName,
      PracticeName:this.practiceName,
      Adddress:this.address,
      city:this.city,
      State:this.state,
      ZipCode:this.zipcode
    }]
    this.submitted = true;
  }

}
