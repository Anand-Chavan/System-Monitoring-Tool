import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetInitialDataComponent } from './get-initial-data.component';

describe('GetInitialDataComponent', () => {
  let component: GetInitialDataComponent;
  let fixture: ComponentFixture<GetInitialDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetInitialDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetInitialDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
