import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-middle-data',
  templateUrl: './get-middle-data.component.html',
  styleUrls: ['./get-middle-data.component.css']
})
export class GetMiddleDataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
