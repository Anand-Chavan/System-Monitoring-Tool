import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetMiddleDataComponent } from './get-middle-data.component';

describe('GetMiddleDataComponent', () => {
  let component: GetMiddleDataComponent;
  let fixture: ComponentFixture<GetMiddleDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetMiddleDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetMiddleDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
